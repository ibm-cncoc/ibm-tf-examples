# Designing a RESTful API With Node and Postgres

## Want to learn how to build this project?

Check out the [blog post](http://mherman.org/blog/2016/03/13/designing-a-restful-api-with-node-and-postgres/#.WJNOqLYrJE4).

## Want to use this project?

1. Fork/Clone
1. Install dependencies - `npm install`
1. Run - `psql -U postgres -f puppies.sql`
1. Run the development server - `npm start`
